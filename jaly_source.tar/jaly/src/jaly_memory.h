#pragma once
extern "C" {
#include "quickjs.h"
}

// Jaly.memory — raw native memory access.
//
// Design (per project philosophy): Jaly is not a sandbox. Pointers are
// real native addresses, exposed to JavaScript as BigInt. There is no
// handle table, no bounds checking, and no permission layer — a script
// that writes to a bad address will fault exactly like C code would.
// This is a deliberate trade for genuine low-level control.
JSValue jaly_memory_create(JSContext *ctx);
