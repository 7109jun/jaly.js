#pragma once
extern "C" {
#include "quickjs.h"
}

JSValue jaly_process_create(JSContext *ctx);
