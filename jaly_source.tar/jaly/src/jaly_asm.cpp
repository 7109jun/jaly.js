// Jaly.asm — assembly-style abstraction instructions.
//
// These are explicitly Jaly-level instructions, not real CPU opcodes:
// MOV/LOAD/STORE map directly onto Jaly.memory's raw pointer operations,
// and ADD/SUB/MUL/DIV/CMP are plain arithmetic helpers with assembly-style
// names. Nothing here executes machine code; it is a naming convention on
// top of real native memory operations, kept deliberately distinct from
// Jaly.native (actual native function calls).

#include "jaly_asm.h"
#include <cstdint>
#include <cstring>

extern "C" {
#include "quickjs.h"
}

namespace {

bool to_ptr(JSContext *ctx, JSValueConst v, uintptr_t *out) {
    if (JS_IsBigInt(v)) {
        uint64_t u;
        if (JS_ToBigUint64(ctx, &u, v)) return false;
        *out = (uintptr_t)u;
        return true;
    }
    int64_t i;
    if (JS_ToInt64(ctx, &i, v)) return false;
    *out = (uintptr_t)i;
    return true;
}

// MOV(destPtr, srcPtr, size) — copy `size` bytes, alias for Jaly.memory.copy
JSValue js_mov(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    uintptr_t dst, src;
    if (!to_ptr(ctx, argv[0], &dst)) return JS_EXCEPTION;
    if (!to_ptr(ctx, argv[1], &src)) return JS_EXCEPTION;
    int64_t size = 0;
    if (JS_ToInt64(ctx, &size, argv[2])) return JS_EXCEPTION;
    memmove((void *)dst, (void *)src, (size_t)(size > 0 ? size : 0));
    return JS_UNDEFINED;
}

// LOAD(ptr, size) — read an integer of `size` bytes (1/2/4/8) from ptr
JSValue js_load(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    uintptr_t ptr;
    if (!to_ptr(ctx, argv[0], &ptr)) return JS_EXCEPTION;
    int64_t size = 4;
    if (JS_ToInt64(ctx, &size, argv[1])) return JS_EXCEPTION;

    switch (size) {
        case 1: { uint8_t v; memcpy(&v, (void *)ptr, 1); return JS_NewInt32(ctx, v); }
        case 2: { uint16_t v; memcpy(&v, (void *)ptr, 2); return JS_NewInt32(ctx, v); }
        case 4: { uint32_t v; memcpy(&v, (void *)ptr, 4); return JS_NewInt64(ctx, v); }
        case 8: { uint64_t v; memcpy(&v, (void *)ptr, 8); return JS_NewBigUint64(ctx, v); }
        default: return JS_ThrowRangeError(ctx, "Jaly.asm.LOAD: size must be 1, 2, 4, or 8");
    }
}

// STORE(ptr, size, value) — write an integer of `size` bytes to ptr
JSValue js_store(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    uintptr_t ptr;
    if (!to_ptr(ctx, argv[0], &ptr)) return JS_EXCEPTION;
    int64_t size = 4;
    if (JS_ToInt64(ctx, &size, argv[1])) return JS_EXCEPTION;

    int64_t value = 0;
    if (JS_IsBigInt(argv[2])) {
        uint64_t u; JS_ToBigUint64(ctx, &u, argv[2]); value = (int64_t)u;
    } else {
        if (JS_ToInt64(ctx, &value, argv[2])) return JS_EXCEPTION;
    }

    switch (size) {
        case 1: { uint8_t v = (uint8_t)value; memcpy((void *)ptr, &v, 1); break; }
        case 2: { uint16_t v = (uint16_t)value; memcpy((void *)ptr, &v, 2); break; }
        case 4: { uint32_t v = (uint32_t)value; memcpy((void *)ptr, &v, 4); break; }
        case 8: { uint64_t v = (uint64_t)value; memcpy((void *)ptr, &v, 8); break; }
        default: return JS_ThrowRangeError(ctx, "Jaly.asm.STORE: size must be 1, 2, 4, or 8");
    }
    return JS_UNDEFINED;
}

#define ARITH_OP(NAME, OP) \
    JSValue js_##NAME(JSContext *ctx, JSValueConst, int, JSValueConst *argv) { \
        double a, b; \
        if (JS_ToFloat64(ctx, &a, argv[0])) return JS_EXCEPTION; \
        if (JS_ToFloat64(ctx, &b, argv[1])) return JS_EXCEPTION; \
        return JS_NewFloat64(ctx, a OP b); \
    }

ARITH_OP(add, +)
ARITH_OP(sub, -)
ARITH_OP(mul, *)

JSValue js_div(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    double a, b;
    if (JS_ToFloat64(ctx, &a, argv[0])) return JS_EXCEPTION;
    if (JS_ToFloat64(ctx, &b, argv[1])) return JS_EXCEPTION;
    if (b == 0) return JS_ThrowRangeError(ctx, "Jaly.asm.DIV: division by zero");
    return JS_NewFloat64(ctx, a / b);
}

// CMP(a, b) -> -1 | 0 | 1
JSValue js_cmp(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    double a, b;
    if (JS_ToFloat64(ctx, &a, argv[0])) return JS_EXCEPTION;
    if (JS_ToFloat64(ctx, &b, argv[1])) return JS_EXCEPTION;
    return JS_NewInt32(ctx, a < b ? -1 : (a > b ? 1 : 0));
}

const JSCFunctionListEntry asm_funcs[] = {
    JS_CFUNC_DEF("MOV", 3, js_mov),
    JS_CFUNC_DEF("LOAD", 2, js_load),
    JS_CFUNC_DEF("STORE", 3, js_store),
    JS_CFUNC_DEF("ADD", 2, js_add),
    JS_CFUNC_DEF("SUB", 2, js_sub),
    JS_CFUNC_DEF("MUL", 2, js_mul),
    JS_CFUNC_DEF("DIV", 2, js_div),
    JS_CFUNC_DEF("CMP", 2, js_cmp),
};

} // namespace

JSValue jaly_asm_create(JSContext *ctx) {
    JSValue obj = JS_NewObject(ctx);
    JS_SetPropertyFunctionList(ctx, obj, asm_funcs,
        sizeof(asm_funcs) / sizeof(asm_funcs[0]));
    return obj;
}
