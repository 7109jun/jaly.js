// Jaly.file — binary-safe file API.
//
// read()    -> ArrayBuffer (raw bytes)
// readText()-> UTF-8 string
// write()   -> accepts ArrayBuffer/TypedArray/string
// exists(), remove(), list()

#include "jaly_file.h"
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <string>
#include <filesystem>

extern "C" {
#include "quickjs.h"
}

namespace fs = std::filesystem;

namespace {

JSValue throw_io(JSContext *ctx, const char *op, const char *path) {
    return JS_ThrowTypeError(ctx, "Jaly.file.%s: failed for '%s'", op, path);
}

JSValue js_read(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    const char *path = JS_ToCString(ctx, argv[0]);
    if (!path) return JS_EXCEPTION;

    FILE *f = fopen(path, "rb");
    if (!f) {
        JSValue err = throw_io(ctx, "read", path);
        JS_FreeCString(ctx, path);
        return err;
    }
    JS_FreeCString(ctx, path);

    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (sz < 0) { fclose(f); return JS_ThrowTypeError(ctx, "Jaly.file.read: could not determine size"); }

    uint8_t *buf = (uint8_t *)malloc((size_t)sz > 0 ? (size_t)sz : 1);
    if (!buf) { fclose(f); return JS_ThrowOutOfMemory(ctx); }
    size_t rd = fread(buf, 1, (size_t)sz, f);
    fclose(f);

    return JS_NewArrayBuffer(ctx, buf, rd, 0,
        [](JSRuntime *, void *, void *p, size_t s) -> void * {
            if (s == 0) { free(p); return nullptr; }
            return realloc(p, s);
        }, nullptr, false);
}

JSValue js_read_text(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    const char *path = JS_ToCString(ctx, argv[0]);
    if (!path) return JS_EXCEPTION;

    FILE *f = fopen(path, "rb");
    if (!f) {
        JSValue err = throw_io(ctx, "readText", path);
        JS_FreeCString(ctx, path);
        return err;
    }
    JS_FreeCString(ctx, path);

    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);

    std::string content((size_t)(sz > 0 ? sz : 0), '\0');
    if (sz > 0) {
        size_t rd = fread(content.data(), 1, (size_t)sz, f);
        content.resize(rd);
    }
    fclose(f);

    return JS_NewStringLen(ctx, content.data(), content.size());
}

JSValue js_write(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    const char *path = JS_ToCString(ctx, argv[0]);
    if (!path) return JS_EXCEPTION;

    const uint8_t *data = nullptr;
    size_t len = 0;
    std::string owned;

    if (JS_IsString(argv[1])) {
        size_t slen = 0;
        const char *s = JS_ToCStringLen(ctx, &slen, argv[1]);
        if (!s) { JS_FreeCString(ctx, path); return JS_EXCEPTION; }
        owned.assign(s, slen);
        JS_FreeCString(ctx, s);
        data = (const uint8_t *)owned.data();
        len = owned.size();
    } else {
        size_t view_off = 0, view_len = 0, bpe = 0;
        JSValue ab = JS_GetTypedArrayBuffer(ctx, argv[1], &view_off, &view_len, &bpe);
        if (!JS_IsException(ab)) {
            size_t total = 0;
            uint8_t *raw = JS_GetArrayBuffer(ctx, &total, ab);
            if (raw) { data = raw + view_off; len = view_len; }
            JS_FreeValue(ctx, ab);
        } else {
            JS_FreeValue(ctx, JS_GetException(ctx));
            size_t total = 0;
            data = JS_GetArrayBuffer(ctx, &total, argv[1]);
            len = total;
        }
    }

    if (!data) {
        JS_FreeCString(ctx, path);
        return JS_ThrowTypeError(ctx, "Jaly.file.write: expected a string, ArrayBuffer, or TypedArray");
    }

    FILE *f = fopen(path, "wb");
    if (!f) {
        JSValue err = throw_io(ctx, "write", path);
        JS_FreeCString(ctx, path);
        return err;
    }
    fwrite(data, 1, len, f);
    fclose(f);
    JS_FreeCString(ctx, path);
    return JS_UNDEFINED;
}

JSValue js_exists(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    const char *path = JS_ToCString(ctx, argv[0]);
    if (!path) return JS_EXCEPTION;
    bool ok = fs::exists(path);
    JS_FreeCString(ctx, path);
    return JS_NewBool(ctx, ok);
}

JSValue js_remove(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    const char *path = JS_ToCString(ctx, argv[0]);
    if (!path) return JS_EXCEPTION;
    std::error_code ec;
    bool ok = fs::remove(path, ec);
    JS_FreeCString(ctx, path);
    return JS_NewBool(ctx, ok && !ec);
}

JSValue js_list(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    const char *path = JS_ToCString(ctx, argv[0]);
    if (!path) return JS_EXCEPTION;

    std::error_code ec;
    if (!fs::is_directory(path, ec) || ec) {
        JSValue err = throw_io(ctx, "list", path);
        JS_FreeCString(ctx, path);
        return err;
    }

    JSValue arr = JS_NewArray(ctx);
    uint32_t idx = 0;
    for (auto &entry : fs::directory_iterator(path, ec)) {
        std::string name = entry.path().filename().string();
        JS_SetPropertyUint32(ctx, arr, idx++, JS_NewStringLen(ctx, name.data(), name.size()));
    }
    JS_FreeCString(ctx, path);
    return arr;
}

JSValue js_is_dir(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    const char *path = JS_ToCString(ctx, argv[0]);
    if (!path) return JS_EXCEPTION;
    std::error_code ec;
    bool ok = fs::is_directory(path, ec);
    JS_FreeCString(ctx, path);
    return JS_NewBool(ctx, ok && !ec);
}

JSValue js_mkdir(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    const char *path = JS_ToCString(ctx, argv[0]);
    if (!path) return JS_EXCEPTION;
    std::error_code ec;
    bool ok = fs::create_directories(path, ec);
    JS_FreeCString(ctx, path);
    return JS_NewBool(ctx, ok && !ec);
}

const JSCFunctionListEntry file_funcs[] = {
    JS_CFUNC_DEF("read", 1, js_read),
    JS_CFUNC_DEF("readText", 1, js_read_text),
    JS_CFUNC_DEF("write", 2, js_write),
    JS_CFUNC_DEF("exists", 1, js_exists),
    JS_CFUNC_DEF("delete", 1, js_remove),
    JS_CFUNC_DEF("list", 1, js_list),
    JS_CFUNC_DEF("isDirectory", 1, js_is_dir),
    JS_CFUNC_DEF("mkdir", 1, js_mkdir),
};

} // namespace

JSValue jaly_file_create(JSContext *ctx) {
    JSValue obj = JS_NewObject(ctx);
    JS_SetPropertyFunctionList(ctx, obj, file_funcs,
        sizeof(file_funcs) / sizeof(file_funcs[0]));
    return obj;
}
