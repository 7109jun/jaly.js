#pragma once
extern "C" {
#include "quickjs.h"
}

JSValue jaly_console_create(JSContext *ctx);

// Installs `console.log/info/warn/error` on the given global object,
// since almost all JS code expects a top-level `console`.
void jaly_console_install_global(JSContext *ctx, JSValueConst global);
