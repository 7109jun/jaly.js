#pragma once
extern "C" {
#include "quickjs.h"
}

JSValue jaly_system_create(JSContext *ctx);
