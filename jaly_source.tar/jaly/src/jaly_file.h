#pragma once
extern "C" {
#include "quickjs.h"
}

JSValue jaly_file_create(JSContext *ctx);
