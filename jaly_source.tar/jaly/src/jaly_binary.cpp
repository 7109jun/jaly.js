// Jaly.binary — bridges JS ArrayBuffer/TypedArray with raw native memory.
// No handle table: everything works directly against pointers (BigInt),
// consistent with Jaly.memory's raw-pointer model.

#include "jaly_binary.h"
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <string>

extern "C" {
#include "quickjs.h"
}

namespace {

bool to_ptr(JSContext *ctx, JSValueConst v, uintptr_t *out) {
    if (JS_IsBigInt(v)) {
        uint64_t u;
        if (JS_ToBigUint64(ctx, &u, v)) return false;
        *out = (uintptr_t)u;
        return true;
    }
    int64_t i;
    if (JS_ToInt64(ctx, &i, v)) return false;
    *out = (uintptr_t)i;
    return true;
}

JSValue throw_err(JSContext *ctx, const char *msg) {
    return JS_ThrowTypeError(ctx, "%s", msg);
}

// toMemory(arrayBufferOrView) -> pointer (BigInt), a fresh malloc'd copy
// of the buffer's bytes. Caller owns it and must Jaly.memory.free() it.
JSValue js_to_memory(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    size_t byte_len = 0;
    uint8_t *data = nullptr;
    JSValue buf = argv[0];

    size_t view_off = 0, view_len = 0, bpe = 0;
    JSValue ab = JS_GetTypedArrayBuffer(ctx, buf, &view_off, &view_len, &bpe);
    if (!JS_IsException(ab)) {
        data = JS_GetArrayBuffer(ctx, &byte_len, ab);
        if (data) { data += view_off; byte_len = view_len; }
        JS_FreeValue(ctx, ab);
    } else {
        JS_FreeValue(ctx, JS_GetException(ctx));
        data = JS_GetArrayBuffer(ctx, &byte_len, buf);
    }

    if (!data) return throw_err(ctx, "Jaly.binary.toMemory: expected an ArrayBuffer or TypedArray");

    void *p = malloc(byte_len > 0 ? byte_len : 1);
    if (!p) return JS_ThrowOutOfMemory(ctx);
    memcpy(p, data, byte_len);

    return JS_NewBigUint64(ctx, (uint64_t)(uintptr_t)p);
}

// fromMemory(ptr, length) -> ArrayBuffer (a copy of `length` bytes at ptr)
JSValue js_from_memory(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    uintptr_t ptr;
    if (!to_ptr(ctx, argv[0], &ptr)) return JS_EXCEPTION;
    int64_t length = 0;
    if (JS_ToInt64(ctx, &length, argv[1])) return JS_EXCEPTION;
    if (length < 0) return JS_ThrowRangeError(ctx, "Jaly.binary.fromMemory: length must be >= 0");

    uint8_t *copy = (uint8_t *)malloc((size_t)length > 0 ? (size_t)length : 1);
    if (!copy) return JS_ThrowOutOfMemory(ctx);
    memcpy(copy, (void *)ptr, (size_t)length);

    return JS_NewArrayBuffer(ctx, copy, (size_t)length, 0,
        [](JSRuntime *, void *, void *p, size_t sz) -> void * {
            if (sz == 0) { free(p); return nullptr; }
            return realloc(p, sz);
        }, nullptr, false);
}

// hex(arrayBuffer) -> lowercase hex string
JSValue js_to_hex(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    size_t len = 0;
    uint8_t *data = JS_GetArrayBuffer(ctx, &len, argv[0]);
    if (!data) return throw_err(ctx, "Jaly.binary.hex: expected an ArrayBuffer");

    std::string out;
    out.reserve(len * 2);
    static const char *hexd = "0123456789abcdef";
    for (size_t i = 0; i < len; i++) {
        out.push_back(hexd[(data[i] >> 4) & 0xf]);
        out.push_back(hexd[data[i] & 0xf]);
    }
    return JS_NewStringLen(ctx, out.data(), out.size());
}

const JSCFunctionListEntry binary_funcs[] = {
    JS_CFUNC_DEF("toMemory", 1, js_to_memory),
    JS_CFUNC_DEF("fromMemory", 2, js_from_memory),
    JS_CFUNC_DEF("hex", 1, js_to_hex),
};

} // namespace

JSValue jaly_binary_create(JSContext *ctx) {
    JSValue obj = JS_NewObject(ctx);
    JS_SetPropertyFunctionList(ctx, obj, binary_funcs,
        sizeof(binary_funcs) / sizeof(binary_funcs[0]));
    return obj;
}
