// Jaly.system — basic host information (CPU, RAM, OS).

#include "jaly_system.h"
#include <string>

extern "C" {
#include "quickjs.h"
}

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#else
#include <unistd.h>
#include <sys/utsname.h>
#include <fstream>
#include <sstream>
#endif

namespace {

JSValue js_cpu_count(JSContext *ctx, JSValueConst, int, JSValueConst *) {
#ifdef _WIN32
    SYSTEM_INFO si;
    GetSystemInfo(&si);
    return JS_NewInt32(ctx, (int32_t)si.dwNumberOfProcessors);
#else
    long n = sysconf(_SC_NPROCESSORS_ONLN);
    return JS_NewInt32(ctx, (int32_t)(n > 0 ? n : 1));
#endif
}

JSValue js_memory_info(JSContext *ctx, JSValueConst, int, JSValueConst *) {
    JSValue obj = JS_NewObject(ctx);
#ifdef _WIN32
    MEMORYSTATUSEX ms{};
    ms.dwLength = sizeof(ms);
    GlobalMemoryStatusEx(&ms);
    JS_SetPropertyStr(ctx, obj, "totalBytes", JS_NewInt64(ctx, (int64_t)ms.ullTotalPhys));
    JS_SetPropertyStr(ctx, obj, "freeBytes", JS_NewInt64(ctx, (int64_t)ms.ullAvailPhys));
    JS_SetPropertyStr(ctx, obj, "percentUsed", JS_NewFloat64(ctx, ms.dwMemoryLoad));
#else
    int64_t total = 0, avail = 0;
    std::ifstream f("/proc/meminfo");
    std::string line;
    while (std::getline(f, line)) {
        int64_t kb = 0;
        if (sscanf(line.c_str(), "MemTotal: %lld kB", (long long *)&kb) == 1) total = kb * 1024;
        if (sscanf(line.c_str(), "MemAvailable: %lld kB", (long long *)&kb) == 1) avail = kb * 1024;
    }
    JS_SetPropertyStr(ctx, obj, "totalBytes", JS_NewInt64(ctx, total));
    JS_SetPropertyStr(ctx, obj, "freeBytes", JS_NewInt64(ctx, avail));
    double pct = total > 0 ? (100.0 * (double)(total - avail) / (double)total) : 0.0;
    JS_SetPropertyStr(ctx, obj, "percentUsed", JS_NewFloat64(ctx, pct));
#endif
    return obj;
}

JSValue js_os_info(JSContext *ctx, JSValueConst, int, JSValueConst *) {
    JSValue obj = JS_NewObject(ctx);
#ifdef _WIN32
    JS_SetPropertyStr(ctx, obj, "platform", JS_NewString(ctx, "windows"));
    OSVERSIONINFOEXW vi{};
    vi.dwOSVersionInfoSize = sizeof(vi);
    // GetVersionEx is deprecated but sufficient for a basic info report;
    // for exact build numbers a manifest + RtlGetVersion would be used.
    std::string ver = "Windows";
    JS_SetPropertyStr(ctx, obj, "version", JS_NewString(ctx, ver.c_str()));
#else
    JS_SetPropertyStr(ctx, obj, "platform", JS_NewString(ctx, "posix"));
    struct utsname u{};
    uname(&u);
    JS_SetPropertyStr(ctx, obj, "version", JS_NewString(ctx, u.release));
#endif
    return obj;
}

const JSCFunctionListEntry system_funcs[] = {
    JS_CFUNC_DEF("cpuCount", 0, js_cpu_count),
    JS_CFUNC_DEF("memoryInfo", 0, js_memory_info),
    JS_CFUNC_DEF("osInfo", 0, js_os_info),
};

} // namespace

JSValue jaly_system_create(JSContext *ctx) {
    JSValue obj = JS_NewObject(ctx);
    JS_SetPropertyFunctionList(ctx, obj, system_funcs,
        sizeof(system_funcs) / sizeof(system_funcs[0]));
    return obj;
}
