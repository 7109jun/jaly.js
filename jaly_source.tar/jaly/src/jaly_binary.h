#pragma once
extern "C" {
#include "quickjs.h"
}

// Creates the Jaly.binary object: bridges ArrayBuffer <-> Jaly.memory handles.
JSValue jaly_binary_create(JSContext *ctx);
