// Jaly.js Runtime — main.cpp
// Standalone JavaScript runtime with low-level native access.
// Single executable, zero external runtime dependencies.

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

extern "C" {
#include "quickjs.h"
}

#include "jaly_memory.h"
#include "jaly_file.h"
#include "jaly_process.h"
#include "jaly_system.h"
#include "jaly_console.h"
#include "jaly_binary.h"
#include "jaly_native.h"
#include "jaly_asm.h"

static const char *JALY_VERSION = "0.1.0";

// ---------------------------------------------------------------------------
// Module registration
// ---------------------------------------------------------------------------

static void jaly_setup_global(JSContext *ctx) {
    JSValue global = JS_GetGlobalObject(ctx);

    JSValue jaly = JS_NewObject(ctx);

    JS_SetPropertyStr(ctx, jaly, "version", JS_NewString(ctx, JALY_VERSION));
    JS_SetPropertyStr(ctx, jaly, "platform",
#ifdef _WIN32
        JS_NewString(ctx, "win32")
#else
        JS_NewString(ctx, "unknown")
#endif
    );

    JS_SetPropertyStr(ctx, jaly, "memory", jaly_memory_create(ctx));
    JS_SetPropertyStr(ctx, jaly, "file", jaly_file_create(ctx));
    JS_SetPropertyStr(ctx, jaly, "process", jaly_process_create(ctx));
    JS_SetPropertyStr(ctx, jaly, "system", jaly_system_create(ctx));
    JS_SetPropertyStr(ctx, jaly, "console", jaly_console_create(ctx));
    JS_SetPropertyStr(ctx, jaly, "binary", jaly_binary_create(ctx));
    JS_SetPropertyStr(ctx, jaly, "native", jaly_native_create(ctx));
    JS_SetPropertyStr(ctx, jaly, "asm", jaly_asm_create(ctx));

    JS_SetPropertyStr(ctx, global, "Jaly", jaly);

    // Also install `console.log/error/warn` on the global object directly,
    // since that's what most JS code expects.
    jaly_console_install_global(ctx, global);

    JS_FreeValue(ctx, global);
}

// ---------------------------------------------------------------------------
// Script execution
// ---------------------------------------------------------------------------

static int jaly_eval_buf(JSContext *ctx, const char *buf, size_t buf_len,
                          const char *filename, int eval_flags) {
    JSValue val;
    int ret = 0;

    if ((eval_flags & JS_EVAL_TYPE_MASK) == JS_EVAL_TYPE_MODULE) {
        val = JS_Eval(ctx, buf, buf_len, filename, eval_flags | JS_EVAL_FLAG_COMPILE_ONLY);
        if (!JS_IsException(val)) {
            val = JS_EvalFunction(ctx, val);
        }
        val = JS_EvalFunction(ctx, val);
    } else {
        val = JS_Eval(ctx, buf, buf_len, filename, eval_flags);
    }

    if (JS_IsException(val)) {
        JSValue exc = JS_GetException(ctx);
        const char *msg = JS_ToCString(ctx, exc);
        fprintf(stderr, "Uncaught exception: %s\n", msg ? msg : "(unknown error)");
        JS_FreeCString(ctx, msg);

        JSValue stack = JS_GetPropertyStr(ctx, exc, "stack");
        if (!JS_IsUndefined(stack)) {
            const char *stack_str = JS_ToCString(ctx, stack);
            if (stack_str && strlen(stack_str) > 0) {
                fprintf(stderr, "%s\n", stack_str);
            }
            JS_FreeCString(ctx, stack_str);
        }
        JS_FreeValue(ctx, stack);
        JS_FreeValue(ctx, exc);
        ret = -1;
    }
    JS_FreeValue(ctx, val);
    return ret;
}

static char *jaly_read_file(const char *path, size_t *out_len) {
    FILE *f = fopen(path, "rb");
    if (!f) return nullptr;

    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    if (sz < 0) { fclose(f); return nullptr; }
    fseek(f, 0, SEEK_SET);

    char *buf = (char *)malloc((size_t)sz + 1);
    if (!buf) { fclose(f); return nullptr; }

    size_t rd = fread(buf, 1, (size_t)sz, f);
    fclose(f);
    buf[rd] = '\0';
    if (out_len) *out_len = rd;
    return buf;
}

static void jaly_run_pending_jobs(JSRuntime *rt) {
    JSContext *ctx1;
    for (;;) {
        int err = JS_ExecutePendingJob(rt, &ctx1);
        if (err <= 0) {
            if (err < 0) {
                JSValue exc = JS_GetException(ctx1);
                const char *msg = JS_ToCString(ctx1, exc);
                fprintf(stderr, "Uncaught (in promise): %s\n", msg ? msg : "(unknown)");
                JS_FreeCString(ctx1, msg);
                JS_FreeValue(ctx1, exc);
            }
            break;
        }
    }
}

// ---------------------------------------------------------------------------
// Embedded self-test script (used by `jaly.exe --selftest`)
// ---------------------------------------------------------------------------

static const char *SELFTEST_SCRIPT =
    "console.log('Hello from Jaly');\n"
    "let p = Jaly.memory.alloc(16);\n"
    "Jaly.memory.write32(p, 1234);\n"
    "console.log('raw pointer =', p);\n"
    "console.log('read back   =', Jaly.memory.read32(p));\n"
    "Jaly.memory.free(p);\n"
    "console.log('Jaly.file.exists(\\'.\\') =', Jaly.file.exists('.'));\n"
    "console.log('platform =', Jaly.platform, 'version =', Jaly.version);\n"
    "console.log('Jaly.asm.ADD(2,3) =', Jaly.asm.ADD(2,3));\n"
    "if (Jaly.platform === 'win32') {\n"
    "  let k32 = Jaly.native.loadLibrary('kernel32.dll');\n"
    "  let fn = Jaly.native.getProcAddress(k32, 'GetTickCount');\n"
    "  console.log('GetTickCount() =', Jaly.native.call(fn, [], 'i64'));\n"
    "}\n";

// ---------------------------------------------------------------------------
// main
// ---------------------------------------------------------------------------

static void print_usage(const char *argv0) {
    fprintf(stderr,
        "Jaly.js Runtime v%s\n"
        "Usage:\n"
        "  %s <script.js> [args...]   Run a JavaScript file\n"
        "  %s -e \"<code>\"             Evaluate an inline expression\n"
        "  %s --selftest              Run the built-in self test\n"
        "  %s --version               Print version\n",
        JALY_VERSION, argv0, argv0, argv0, argv0);
}

int main(int argc, char **argv) {
    if (argc < 2) {
        print_usage(argv[0]);
        return 1;
    }

    if (strcmp(argv[1], "--version") == 0) {
        printf("jaly.js v%s\n", JALY_VERSION);
        return 0;
    }

    JSRuntime *rt = JS_NewRuntime();
    if (!rt) {
        fprintf(stderr, "jaly: failed to create JS runtime\n");
        return 1;
    }
    JS_SetMemoryLimit(rt, (size_t)512 * 1024 * 1024); // 512MB default cap
    JS_SetMaxStackSize(rt, 1024 * 1024);

    JSContext *ctx = JS_NewContext(rt);
    if (!ctx) {
        fprintf(stderr, "jaly: failed to create JS context\n");
        JS_FreeRuntime(rt);
        return 1;
    }

    jaly_setup_global(ctx);

    int ret = 0;

    if (strcmp(argv[1], "--selftest") == 0) {
        ret = jaly_eval_buf(ctx, SELFTEST_SCRIPT, strlen(SELFTEST_SCRIPT),
                             "<selftest>", JS_EVAL_TYPE_GLOBAL);
    } else if (strcmp(argv[1], "-e") == 0) {
        if (argc < 3) {
            fprintf(stderr, "jaly: -e requires an argument\n");
            ret = 1;
        } else {
            ret = jaly_eval_buf(ctx, argv[2], strlen(argv[2]), "<eval>", JS_EVAL_TYPE_GLOBAL);
        }
    } else {
        const char *path = argv[1];
        size_t len = 0;
        char *src = jaly_read_file(path, &len);
        if (!src) {
            fprintf(stderr, "jaly: could not open file '%s'\n", path);
            ret = 1;
        } else {
            int flags = JS_EVAL_TYPE_GLOBAL;
            ret = jaly_eval_buf(ctx, src, len, path, flags);
            free(src);
        }
    }

    jaly_run_pending_jobs(rt);

    JS_FreeContext(ctx);
    JS_FreeRuntime(rt);

    return ret != 0 ? 1 : 0;
}
