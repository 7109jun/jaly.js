#pragma once
extern "C" {
#include "quickjs.h"
}

// Jaly.asm — assembly-inspired abstraction instructions (MOV/LOAD/STORE/
// ADD/SUB/MUL/DIV/CMP) that operate on Jaly's real memory model. These are
// Jaly-level abstraction instructions, NOT real CPU opcodes — they don't
// execute machine code, they call into the same native memory operations
// Jaly.memory exposes, just under assembly-style names.
JSValue jaly_asm_create(JSContext *ctx);
