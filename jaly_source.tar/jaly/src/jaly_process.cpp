// Jaly.process — process execution and inspection.
//
// Jaly.process.run(cmd)      -> { exitCode, stdout, stderr }
// Jaly.process.list()        -> [{ pid, name }]
// Jaly.process.info(pid)     -> { pid, name, memoryBytes } | null
//
// Windows build uses native Win32 APIs (CreateProcess, Toolhelp32).
// A POSIX fallback is compiled in for development/testing on Linux;
// the spec's shipped target is Windows-only.

#include "jaly_process.h"
#include <string>
#include <vector>
#include <cstdio>
#include <cstdlib>

extern "C" {
#include "quickjs.h"
}

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <tlhelp32.h>
#include <psapi.h>
#else
#include <dirent.h>
#include <fstream>
#include <sstream>
#endif

namespace {

#ifdef _WIN32

std::string wide_to_utf8(const std::wstring &w) {
    if (w.empty()) return {};
    int len = WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), nullptr, 0, nullptr, nullptr);
    std::string out(len, '\0');
    WideCharToMultiByte(CP_UTF8, 0, w.data(), (int)w.size(), out.data(), len, nullptr, nullptr);
    return out;
}

std::wstring utf8_to_wide(const std::string &s) {
    if (s.empty()) return {};
    int len = MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), nullptr, 0);
    std::wstring out(len, L'\0');
    MultiByteToWideChar(CP_UTF8, 0, s.data(), (int)s.size(), out.data(), len);
    return out;
}

// Runs `cmd` via cmd.exe /C, capturing stdout/stderr through pipes.
JSValue js_run(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    const char *cmd_utf8 = JS_ToCString(ctx, argv[0]);
    if (!cmd_utf8) return JS_EXCEPTION;
    std::string cmd(cmd_utf8);
    JS_FreeCString(ctx, cmd_utf8);

    SECURITY_ATTRIBUTES sa{};
    sa.nLength = sizeof(sa);
    sa.bInheritHandle = TRUE;

    HANDLE out_r, out_w, err_r, err_w;
    if (!CreatePipe(&out_r, &out_w, &sa, 0) || !SetHandleInformation(out_r, HANDLE_FLAG_INHERIT, 0)) {
        return JS_ThrowTypeError(ctx, "Jaly.process.run: failed to create stdout pipe");
    }
    if (!CreatePipe(&err_r, &err_w, &sa, 0) || !SetHandleInformation(err_r, HANDLE_FLAG_INHERIT, 0)) {
        return JS_ThrowTypeError(ctx, "Jaly.process.run: failed to create stderr pipe");
    }

    STARTUPINFOW si{};
    si.cb = sizeof(si);
    si.hStdOutput = out_w;
    si.hStdError = err_w;
    si.dwFlags |= STARTF_USESTDHANDLES;

    PROCESS_INFORMATION pi{};
    std::wstring full = L"cmd.exe /C " + utf8_to_wide(cmd);
    std::vector<wchar_t> mutable_cmd(full.begin(), full.end());
    mutable_cmd.push_back(L'\0');

    BOOL ok = CreateProcessW(nullptr, mutable_cmd.data(), nullptr, nullptr, TRUE,
                              CREATE_NO_WINDOW, nullptr, nullptr, &si, &pi);
    CloseHandle(out_w);
    CloseHandle(err_w);

    if (!ok) {
        CloseHandle(out_r);
        CloseHandle(err_r);
        return JS_ThrowTypeError(ctx, "Jaly.process.run: failed to launch process");
    }

    auto drain = [](HANDLE h) {
        std::string result;
        char buf[4096];
        DWORD n = 0;
        while (ReadFile(h, buf, sizeof(buf), &n, nullptr) && n > 0) {
            result.append(buf, n);
        }
        return result;
    };

    std::string out_data = drain(out_r);
    std::string err_data = drain(err_r);
    CloseHandle(out_r);
    CloseHandle(err_r);

    WaitForSingleObject(pi.hProcess, INFINITE);
    DWORD exit_code = 0;
    GetExitCodeProcess(pi.hProcess, &exit_code);
    CloseHandle(pi.hProcess);
    CloseHandle(pi.hThread);

    JSValue result = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, result, "exitCode", JS_NewInt32(ctx, (int32_t)exit_code));
    JS_SetPropertyStr(ctx, result, "stdout", JS_NewStringLen(ctx, out_data.data(), out_data.size()));
    JS_SetPropertyStr(ctx, result, "stderr", JS_NewStringLen(ctx, err_data.data(), err_data.size()));
    return result;
}

JSValue js_list(JSContext *ctx, JSValueConst, int, JSValueConst *) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE) {
        return JS_ThrowTypeError(ctx, "Jaly.process.list: snapshot failed");
    }

    PROCESSENTRY32W entry{};
    entry.dwSize = sizeof(entry);

    JSValue arr = JS_NewArray(ctx);
    uint32_t idx = 0;
    if (Process32FirstW(snap, &entry)) {
        do {
            JSValue item = JS_NewObject(ctx);
            JS_SetPropertyStr(ctx, item, "pid", JS_NewInt64(ctx, (int64_t)entry.th32ProcessID));
            std::string name = wide_to_utf8(entry.szExeFile);
            JS_SetPropertyStr(ctx, item, "name", JS_NewStringLen(ctx, name.data(), name.size()));
            JS_SetPropertyUint32(ctx, arr, idx++, item);
        } while (Process32NextW(snap, &entry));
    }
    CloseHandle(snap);
    return arr;
}

JSValue js_info(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    int64_t pid = 0;
    if (JS_ToInt64(ctx, &pid, argv[0])) return JS_EXCEPTION;

    HANDLE h = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, (DWORD)pid);
    if (!h) return JS_NULL;

    wchar_t name_buf[MAX_PATH]{};
    DWORD name_len = MAX_PATH;
    std::string name;
    if (QueryFullProcessImageNameW(h, 0, name_buf, &name_len)) {
        name = wide_to_utf8(std::wstring(name_buf, name_len));
    }

    PROCESS_MEMORY_COUNTERS pmc{};
    SIZE_T working_set = 0;
    if (GetProcessMemoryInfo(h, &pmc, sizeof(pmc))) {
        working_set = pmc.WorkingSetSize;
    }
    CloseHandle(h);

    JSValue obj = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, obj, "pid", JS_NewInt64(ctx, pid));
    JS_SetPropertyStr(ctx, obj, "name", JS_NewStringLen(ctx, name.data(), name.size()));
    JS_SetPropertyStr(ctx, obj, "memoryBytes", JS_NewInt64(ctx, (int64_t)working_set));
    return obj;
}

#else // ---- POSIX fallback (development/testing builds) --------------------

JSValue js_run(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    const char *cmd = JS_ToCString(ctx, argv[0]);
    if (!cmd) return JS_EXCEPTION;

    std::string full = std::string(cmd) + " 2>/tmp/jaly_stderr_capture";
    JS_FreeCString(ctx, cmd);

    FILE *pipe = popen(full.c_str(), "r");
    if (!pipe) return JS_ThrowTypeError(ctx, "Jaly.process.run: failed to launch process");

    std::string out;
    char buf[4096];
    size_t n;
    while ((n = fread(buf, 1, sizeof(buf), pipe)) > 0) out.append(buf, n);
    int status = pclose(pipe);

    std::string err;
    std::ifstream ef("/tmp/jaly_stderr_capture");
    std::stringstream ss;
    ss << ef.rdbuf();
    err = ss.str();

    JSValue result = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, result, "exitCode", JS_NewInt32(ctx, WEXITSTATUS(status)));
    JS_SetPropertyStr(ctx, result, "stdout", JS_NewStringLen(ctx, out.data(), out.size()));
    JS_SetPropertyStr(ctx, result, "stderr", JS_NewStringLen(ctx, err.data(), err.size()));
    return result;
}

JSValue js_list(JSContext *ctx, JSValueConst, int, JSValueConst *) {
    JSValue arr = JS_NewArray(ctx);
    uint32_t idx = 0;
    DIR *d = opendir("/proc");
    if (!d) return arr;
    struct dirent *ent;
    while ((ent = readdir(d)) != nullptr) {
        bool numeric = ent->d_name[0] != '\0';
        for (const char *p = ent->d_name; *p; p++) {
            if (*p < '0' || *p > '9') { numeric = false; break; }
        }
        if (!numeric) continue;

        std::string comm_path = std::string("/proc/") + ent->d_name + "/comm";
        std::ifstream f(comm_path);
        std::string name;
        std::getline(f, name);
        if (name.empty()) continue;

        JSValue item = JS_NewObject(ctx);
        JS_SetPropertyStr(ctx, item, "pid", JS_NewInt64(ctx, atoll(ent->d_name)));
        JS_SetPropertyStr(ctx, item, "name", JS_NewStringLen(ctx, name.data(), name.size()));
        JS_SetPropertyUint32(ctx, arr, idx++, item);
    }
    closedir(d);
    return arr;
}

JSValue js_info(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    int64_t pid = 0;
    if (JS_ToInt64(ctx, &pid, argv[0])) return JS_EXCEPTION;

    std::string comm_path = "/proc/" + std::to_string(pid) + "/comm";
    std::ifstream f(comm_path);
    if (!f.good()) return JS_NULL;
    std::string name;
    std::getline(f, name);

    int64_t rss_kb = 0;
    std::ifstream status("/proc/" + std::to_string(pid) + "/status");
    std::string line;
    while (std::getline(status, line)) {
        if (line.rfind("VmRSS:", 0) == 0) {
            rss_kb = atoll(line.c_str() + 6);
            break;
        }
    }

    JSValue obj = JS_NewObject(ctx);
    JS_SetPropertyStr(ctx, obj, "pid", JS_NewInt64(ctx, pid));
    JS_SetPropertyStr(ctx, obj, "name", JS_NewStringLen(ctx, name.data(), name.size()));
    JS_SetPropertyStr(ctx, obj, "memoryBytes", JS_NewInt64(ctx, rss_kb * 1024));
    return obj;
}

#endif

const JSCFunctionListEntry process_funcs[] = {
    JS_CFUNC_DEF("run", 1, js_run),
    JS_CFUNC_DEF("list", 0, js_list),
    JS_CFUNC_DEF("info", 1, js_info),
};

} // namespace

JSValue jaly_process_create(JSContext *ctx) {
    JSValue obj = JS_NewObject(ctx);
    JS_SetPropertyFunctionList(ctx, obj, process_funcs,
        sizeof(process_funcs) / sizeof(process_funcs[0]));
    return obj;
}
