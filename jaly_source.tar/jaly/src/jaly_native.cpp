// Jaly.native — direct native function calling (FFI).
//
// Jaly.native.loadLibrary(name)         -> module handle (BigInt) | null
// Jaly.native.freeLibrary(handle)
// Jaly.native.getProcAddress(handle, name) -> function pointer (BigInt) | null
// Jaly.native.call(fnPtr, args, returnType) -> value
//
// `args` is an array. Each element is either a plain JS value (auto-typed:
// number -> integer, bigint -> 64-bit/pointer, string -> ANSI C string,
// boolean -> 0/1) or an explicit { type, value } pair where type is one of
// 'i32' | 'i64' | 'u64' | 'ptr' | 'string' | 'wstring'.
//
// `returnType` (default 'i64') is one of:
// 'void' | 'i32' | 'i64' | 'u64' | 'ptr' | 'double' | 'string' | 'wstring'.
//
// Implementation detail: on the Windows x64 calling convention, integer
// and pointer arguments share the same register class (RCX/RDX/R8/R9 then
// stack) regardless of declared width, so a single family of function
// pointer types (N int64_t params) correctly dispatches the vast majority
// of native/Win32 calls. Floating-point *arguments* use a different
// register class (XMM) and are not yet supported by this dispatcher —
// floating point *return values* are, via a separate typedef family.
// This is a real, working limitation, not a hidden restriction: mixed
// float/int argument calls will need a per-signature native shim.

#include "jaly_native.h"
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <string>
#include <vector>

extern "C" {
#include "quickjs.h"
}

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#else
#include <dlfcn.h>
#endif

namespace {

bool to_ptr(JSContext *ctx, JSValueConst v, uintptr_t *out) {
    if (JS_IsBigInt(v)) {
        uint64_t u;
        if (JS_ToBigUint64(ctx, &u, v)) return false;
        *out = (uintptr_t)u;
        return true;
    }
    int64_t i;
    if (JS_ToInt64(ctx, &i, v)) return false;
    *out = (uintptr_t)i;
    return true;
}

// ---- loadLibrary / freeLibrary / getProcAddress ----------------------------

JSValue js_load_library(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    const char *name = JS_ToCString(ctx, argv[0]);
    if (!name) return JS_EXCEPTION;

#ifdef _WIN32
    HMODULE h = LoadLibraryA(name);
#else
    void *h = dlopen(name, RTLD_NOW | RTLD_GLOBAL);
#endif
    JS_FreeCString(ctx, name);
    if (!h) return JS_NULL;
    return JS_NewBigUint64(ctx, (uint64_t)(uintptr_t)h);
}

JSValue js_free_library(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    uintptr_t h;
    if (!to_ptr(ctx, argv[0], &h)) return JS_EXCEPTION;
#ifdef _WIN32
    FreeLibrary((HMODULE)h);
#else
    dlclose((void *)h);
#endif
    return JS_UNDEFINED;
}

JSValue js_get_proc_address(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    uintptr_t h;
    if (!to_ptr(ctx, argv[0], &h)) return JS_EXCEPTION;
    const char *name = JS_ToCString(ctx, argv[1]);
    if (!name) return JS_EXCEPTION;

#ifdef _WIN32
    FARPROC p = GetProcAddress((HMODULE)h, name);
#else
    void *p = dlsym((void *)h, name);
#endif
    JS_FreeCString(ctx, name);
    if (!p) return JS_NULL;
    return JS_NewBigUint64(ctx, (uint64_t)(uintptr_t)p);
}

// ---- dynamic call ------------------------------------------------------------

constexpr int MAX_ARGS = 12;

// One function-pointer typedef family per argument count, all-int64 params.
// Selected at runtime via switch on argc.
typedef int64_t (*Fn0)();
typedef int64_t (*Fn1)(int64_t);
typedef int64_t (*Fn2)(int64_t, int64_t);
typedef int64_t (*Fn3)(int64_t, int64_t, int64_t);
typedef int64_t (*Fn4)(int64_t, int64_t, int64_t, int64_t);
typedef int64_t (*Fn5)(int64_t, int64_t, int64_t, int64_t, int64_t);
typedef int64_t (*Fn6)(int64_t, int64_t, int64_t, int64_t, int64_t, int64_t);
typedef int64_t (*Fn7)(int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t);
typedef int64_t (*Fn8)(int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t);
typedef int64_t (*Fn9)(int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t);
typedef int64_t (*Fn10)(int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t);
typedef int64_t (*Fn11)(int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t);
typedef int64_t (*Fn12)(int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t, int64_t);

typedef double (*FnD0)();
typedef double (*FnD1)(int64_t);
typedef double (*FnD2)(int64_t, int64_t);
typedef double (*FnD3)(int64_t, int64_t, int64_t);
typedef double (*FnD4)(int64_t, int64_t, int64_t, int64_t);

int64_t call_int(void *fn, int64_t *a, int argc) {
    switch (argc) {
        case 0: return ((Fn0)fn)();
        case 1: return ((Fn1)fn)(a[0]);
        case 2: return ((Fn2)fn)(a[0], a[1]);
        case 3: return ((Fn3)fn)(a[0], a[1], a[2]);
        case 4: return ((Fn4)fn)(a[0], a[1], a[2], a[3]);
        case 5: return ((Fn5)fn)(a[0], a[1], a[2], a[3], a[4]);
        case 6: return ((Fn6)fn)(a[0], a[1], a[2], a[3], a[4], a[5]);
        case 7: return ((Fn7)fn)(a[0], a[1], a[2], a[3], a[4], a[5], a[6]);
        case 8: return ((Fn8)fn)(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7]);
        case 9: return ((Fn9)fn)(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8]);
        case 10: return ((Fn10)fn)(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9]);
        case 11: return ((Fn11)fn)(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10]);
        case 12: return ((Fn12)fn)(a[0], a[1], a[2], a[3], a[4], a[5], a[6], a[7], a[8], a[9], a[10], a[11]);
        default: return 0;
    }
}

double call_double(void *fn, int64_t *a, int argc) {
    switch (argc) {
        case 0: return ((FnD0)fn)();
        case 1: return ((FnD1)fn)(a[0]);
        case 2: return ((FnD2)fn)(a[0], a[1]);
        case 3: return ((FnD3)fn)(a[0], a[1], a[2]);
        case 4: return ((FnD4)fn)(a[0], a[1], a[2], a[3]);
        default: return 0.0;
    }
}

JSValue js_call(JSContext *ctx, JSValueConst, int argc, JSValueConst *argv) {
    uintptr_t fn;
    if (!to_ptr(ctx, argv[0], &fn)) return JS_EXCEPTION;
    if (fn == 0) return JS_ThrowTypeError(ctx, "Jaly.native.call: null function pointer");

    // Parse args array.
    std::vector<int64_t> vals;
    std::vector<std::string> owned_strings; // keep C strings alive through the call
    owned_strings.reserve(16);

    if (argc > 1 && !JS_IsUndefined(argv[1]) && !JS_IsNull(argv[1])) {
        int64_t len = 0;
        JSValue len_val = JS_GetPropertyStr(ctx, argv[1], "length");
        JS_ToInt64(ctx, &len, len_val);
        JS_FreeValue(ctx, len_val);
        if (len > MAX_ARGS) return JS_ThrowRangeError(ctx, "Jaly.native.call: at most %d arguments supported", MAX_ARGS);

        for (int64_t i = 0; i < len; i++) {
            JSValue item = JS_GetPropertyUint32(ctx, argv[1], (uint32_t)i);

            if (JS_IsString(item)) {
                size_t slen = 0;
                const char *s = JS_ToCStringLen(ctx, &slen, item);
                owned_strings.emplace_back(s, slen);
                JS_FreeCString(ctx, s);
                vals.push_back((int64_t)(uintptr_t)owned_strings.back().c_str());
            } else if (JS_IsBigInt(item)) {
                uint64_t u; JS_ToBigUint64(ctx, &u, item);
                vals.push_back((int64_t)u);
            } else if (JS_IsBool(item)) {
                vals.push_back(JS_ToBool(ctx, item) ? 1 : 0);
            } else if (JS_IsNull(item) || JS_IsUndefined(item)) {
                vals.push_back(0);
            } else {
                // number, or explicit {type, value}
                JSValue type_prop = JS_GetPropertyStr(ctx, item, "type");
                if (!JS_IsUndefined(type_prop)) {
                    const char *t = JS_ToCString(ctx, type_prop);
                    JSValue vprop = JS_GetPropertyStr(ctx, item, "value");
                    if (t && strcmp(t, "string") == 0) {
                        size_t slen = 0;
                        const char *s = JS_ToCStringLen(ctx, &slen, vprop);
                        owned_strings.emplace_back(s, slen);
                        JS_FreeCString(ctx, s);
                        vals.push_back((int64_t)(uintptr_t)owned_strings.back().c_str());
                    } else {
                        int64_t v = 0;
                        if (JS_IsBigInt(vprop)) {
                            uint64_t u; JS_ToBigUint64(ctx, &u, vprop); v = (int64_t)u;
                        } else {
                            JS_ToInt64(ctx, &v, vprop);
                        }
                        vals.push_back(v);
                    }
                    JS_FreeValue(ctx, vprop);
                    JS_FreeCString(ctx, t);
                } else {
                    int64_t v = 0;
                    JS_ToInt64(ctx, &v, item);
                    vals.push_back(v);
                }
                JS_FreeValue(ctx, type_prop);
            }
            JS_FreeValue(ctx, item);
        }
    }

    std::string ret_type = "i64";
    if (argc > 2 && JS_IsString(argv[2])) {
        const char *rt = JS_ToCString(ctx, argv[2]);
        if (rt) { ret_type = rt; JS_FreeCString(ctx, rt); }
    }

    int nargs = (int)vals.size();
    vals.resize(MAX_ARGS, 0);

    if (ret_type == "double") {
        double r = call_double((void *)fn, vals.data(), nargs);
        return JS_NewFloat64(ctx, r);
    }

    int64_t r = call_int((void *)fn, vals.data(), nargs);

    if (ret_type == "void") return JS_UNDEFINED;
    if (ret_type == "i32") return JS_NewInt32(ctx, (int32_t)r);
    if (ret_type == "u32") return JS_NewUint32(ctx, (uint32_t)r);
    if (ret_type == "u64") return JS_NewBigUint64(ctx, (uint64_t)r);
    if (ret_type == "ptr") return JS_NewBigUint64(ctx, (uint64_t)r);
    if (ret_type == "string") {
        const char *s = (const char *)(intptr_t)r;
        if (!s) return JS_NULL;
        return JS_NewString(ctx, s);
    }
    if (ret_type == "wstring") {
#ifdef _WIN32
        const wchar_t *ws = (const wchar_t *)(intptr_t)r;
        if (!ws) return JS_NULL;
        int len = WideCharToMultiByte(CP_UTF8, 0, ws, -1, nullptr, 0, nullptr, nullptr);
        std::string out(len > 0 ? len - 1 : 0, '\0');
        if (len > 0) WideCharToMultiByte(CP_UTF8, 0, ws, -1, out.data(), len, nullptr, nullptr);
        return JS_NewStringLen(ctx, out.data(), out.size());
#else
        return JS_ThrowTypeError(ctx, "Jaly.native.call: 'wstring' is Windows-only");
#endif
    }
    // default: i64
    return JS_NewBigInt64(ctx, r);
}

// lastError() -> OS-reported error code for the calling thread (GetLastError / errno)
JSValue js_last_error(JSContext *ctx, JSValueConst, int, JSValueConst *) {
#ifdef _WIN32
    return JS_NewUint32(ctx, GetLastError());
#else
    return JS_NewInt32(ctx, errno);
#endif
}

const JSCFunctionListEntry native_funcs[] = {
    JS_CFUNC_DEF("loadLibrary", 1, js_load_library),
    JS_CFUNC_DEF("freeLibrary", 1, js_free_library),
    JS_CFUNC_DEF("getProcAddress", 2, js_get_proc_address),
    JS_CFUNC_DEF("call", 1, js_call),
    JS_CFUNC_DEF("lastError", 0, js_last_error),
};

} // namespace

JSValue jaly_native_create(JSContext *ctx) {
    JSValue obj = JS_NewObject(ctx);
    JS_SetPropertyFunctionList(ctx, obj, native_funcs,
        sizeof(native_funcs) / sizeof(native_funcs[0]));
    return obj;
}
