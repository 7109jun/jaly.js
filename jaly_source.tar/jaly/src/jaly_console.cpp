// Jaly.console — simple stdio-backed console, mirrored onto the global
// `console` object so ordinary JavaScript code "just works".

#include "jaly_console.h"
#include <cstdio>

extern "C" {
#include "quickjs.h"
}

namespace {

void print_args(JSContext *ctx, int argc, JSValueConst *argv, FILE *stream) {
    for (int i = 0; i < argc; i++) {
        if (i > 0) fputc(' ', stream);
        const char *s = JS_ToCString(ctx, argv[i]);
        if (s) {
            fputs(s, stream);
            JS_FreeCString(ctx, s);
        }
    }
    fputc('\n', stream);
}

JSValue js_log(JSContext *ctx, JSValueConst, int argc, JSValueConst *argv) {
    print_args(ctx, argc, argv, stdout);
    return JS_UNDEFINED;
}

JSValue js_error(JSContext *ctx, JSValueConst, int argc, JSValueConst *argv) {
    print_args(ctx, argc, argv, stderr);
    return JS_UNDEFINED;
}

const JSCFunctionListEntry console_funcs[] = {
    JS_CFUNC_DEF("log", 0, js_log),
    JS_CFUNC_DEF("info", 0, js_log),
    JS_CFUNC_DEF("warn", 0, js_error),
    JS_CFUNC_DEF("error", 0, js_error),
};

} // namespace

JSValue jaly_console_create(JSContext *ctx) {
    JSValue obj = JS_NewObject(ctx);
    JS_SetPropertyFunctionList(ctx, obj, console_funcs,
        sizeof(console_funcs) / sizeof(console_funcs[0]));
    return obj;
}

void jaly_console_install_global(JSContext *ctx, JSValueConst global) {
    JSValue console = JS_NewObject(ctx);
    JS_SetPropertyFunctionList(ctx, console, console_funcs,
        sizeof(console_funcs) / sizeof(console_funcs[0]));
    JS_SetPropertyStr(ctx, global, "console", console);
}
