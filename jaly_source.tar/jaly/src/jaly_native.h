#pragma once
extern "C" {
#include "quickjs.h"
}

// Jaly.native — thin FFI layer: load native libraries, resolve symbols,
// and call arbitrary native functions directly from JavaScript.
// No permission system, no allow-list — if the OS lets the Jaly process
// do it, Jaly.native lets the script do it.
JSValue jaly_native_create(JSContext *ctx);
