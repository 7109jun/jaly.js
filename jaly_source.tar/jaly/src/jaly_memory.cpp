// Jaly.memory — raw native memory access.
//
// No handle table. No bounds checking. No permission layer.
// Pointers are real addresses, passed to/from JS as BigInt (since a
// 64-bit address does not fit a JS double without losing precision).
//
// This is intentional: Jaly is a native runtime the user chose to run,
// not a sandbox. A script that dereferences a bad pointer will crash
// exactly like equivalent C code would — same as any other native tool.

#include "jaly_memory.h"
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <type_traits>

extern "C" {
#include "quickjs.h"
}

namespace {

// Reads a pointer-sized value from a BigInt/Number argument.
bool to_ptr(JSContext *ctx, JSValueConst v, uintptr_t *out) {
    uint64_t u = 0;
    if (JS_IsBigInt(v)) {
        if (JS_ToBigUint64(ctx, &u, v)) return false;
    } else {
        int64_t i = 0;
        if (JS_ToInt64(ctx, &i, v)) return false;
        u = (uint64_t)i;
    }
    *out = (uintptr_t)u;
    return true;
}

JSValue from_ptr(JSContext *ctx, uintptr_t p) {
    return JS_NewBigUint64(ctx, (uint64_t)p);
}

// ---- alloc / free / realloc ------------------------------------------------

JSValue js_alloc(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    int64_t size = 0;
    if (JS_ToInt64(ctx, &size, argv[0])) return JS_EXCEPTION;
    if (size < 0) return JS_ThrowRangeError(ctx, "Jaly.memory.alloc: size must be >= 0");

    void *p = malloc((size_t)size > 0 ? (size_t)size : 1);
    if (!p) return JS_ThrowOutOfMemory(ctx);
    return from_ptr(ctx, (uintptr_t)p);
}

JSValue js_calloc(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    int64_t count = 0, elem_size = 0;
    if (JS_ToInt64(ctx, &count, argv[0])) return JS_EXCEPTION;
    if (JS_ToInt64(ctx, &elem_size, argv[1])) return JS_EXCEPTION;
    if (count < 0 || elem_size < 0) return JS_ThrowRangeError(ctx, "Jaly.memory.calloc: negative size");

    void *p = calloc((size_t)count, (size_t)elem_size);
    if (!p) return JS_ThrowOutOfMemory(ctx);
    return from_ptr(ctx, (uintptr_t)p);
}

JSValue js_realloc(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    uintptr_t ptr;
    if (!to_ptr(ctx, argv[0], &ptr)) return JS_EXCEPTION;
    int64_t size = 0;
    if (JS_ToInt64(ctx, &size, argv[1])) return JS_EXCEPTION;
    if (size < 0) return JS_ThrowRangeError(ctx, "Jaly.memory.realloc: size must be >= 0");

    void *p = realloc((void *)ptr, (size_t)size);
    if (!p && size != 0) return JS_ThrowOutOfMemory(ctx);
    return from_ptr(ctx, (uintptr_t)p);
}

JSValue js_free(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    uintptr_t ptr;
    if (!to_ptr(ctx, argv[0], &ptr)) return JS_EXCEPTION;
    free((void *)ptr);
    return JS_UNDEFINED;
}

// ---- pointer arithmetic -----------------------------------------------------

JSValue js_add(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    uintptr_t ptr;
    if (!to_ptr(ctx, argv[0], &ptr)) return JS_EXCEPTION;
    int64_t offset = 0;
    if (JS_ToInt64(ctx, &offset, argv[1])) return JS_EXCEPTION;
    return from_ptr(ctx, (uintptr_t)((intptr_t)ptr + offset));
}

JSValue js_is_null(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    uintptr_t ptr;
    if (!to_ptr(ctx, argv[0], &ptr)) return JS_EXCEPTION;
    return JS_NewBool(ctx, ptr == 0);
}

// ---- read/write --------------------------------------------------------------

template <typename T>
JSValue read_int(JSContext *ctx, JSValueConst *argv, int argc) {
    uintptr_t ptr;
    if (!to_ptr(ctx, argv[0], &ptr)) return JS_EXCEPTION;
    int64_t offset = 0;
    if (argc > 1 && !JS_IsUndefined(argv[1])) {
        if (JS_ToInt64(ctx, &offset, argv[1])) return JS_EXCEPTION;
    }

    T val;
    memcpy(&val, (void *)(ptr + offset), sizeof(T));

    if (sizeof(T) == 8) {
        if (std::is_signed<T>::value) return JS_NewBigInt64(ctx, (int64_t)val);
        return JS_NewBigUint64(ctx, (uint64_t)val);
    }
    return JS_NewInt64(ctx, (int64_t)(uint64_t)val);
}

template <typename T>
JSValue write_int(JSContext *ctx, JSValueConst *argv, int argc) {
    uintptr_t ptr;
    if (!to_ptr(ctx, argv[0], &ptr)) return JS_EXCEPTION;
    int64_t offset = 0, value_idx = 1;
    if (argc >= 3) {
        if (JS_ToInt64(ctx, &offset, argv[1])) return JS_EXCEPTION;
        value_idx = 2;
    }

    T val;
    if (sizeof(T) == 8) {
        int64_t v64;
        if (JS_IsBigInt(argv[value_idx])) {
            uint64_t u;
            if (JS_ToBigUint64(ctx, &u, argv[value_idx])) return JS_EXCEPTION;
            v64 = (int64_t)u;
        } else {
            if (JS_ToInt64(ctx, &v64, argv[value_idx])) return JS_EXCEPTION;
        }
        val = (T)v64;
    } else {
        int64_t v;
        if (JS_ToInt64(ctx, &v, argv[value_idx])) return JS_EXCEPTION;
        val = (T)v;
    }
    memcpy((void *)(ptr + offset), &val, sizeof(T));
    return JS_UNDEFINED;
}

JSValue js_read8(JSContext *ctx, JSValueConst, int argc, JSValueConst *argv)   { return read_int<uint8_t>(ctx, argv, argc); }
JSValue js_read16(JSContext *ctx, JSValueConst, int argc, JSValueConst *argv)  { return read_int<uint16_t>(ctx, argv, argc); }
JSValue js_read32(JSContext *ctx, JSValueConst, int argc, JSValueConst *argv)  { return read_int<uint32_t>(ctx, argv, argc); }
JSValue js_read64(JSContext *ctx, JSValueConst, int argc, JSValueConst *argv)  { return read_int<uint64_t>(ctx, argv, argc); }
JSValue js_readPtr(JSContext *ctx, JSValueConst, int argc, JSValueConst *argv) { return read_int<uintptr_t>(ctx, argv, argc); }

JSValue js_write8(JSContext *ctx, JSValueConst, int argc, JSValueConst *argv)   { return write_int<uint8_t>(ctx, argv, argc); }
JSValue js_write16(JSContext *ctx, JSValueConst, int argc, JSValueConst *argv)  { return write_int<uint16_t>(ctx, argv, argc); }
JSValue js_write32(JSContext *ctx, JSValueConst, int argc, JSValueConst *argv)  { return write_int<uint32_t>(ctx, argv, argc); }
JSValue js_write64(JSContext *ctx, JSValueConst, int argc, JSValueConst *argv)  { return write_int<uint64_t>(ctx, argv, argc); }
JSValue js_writePtr(JSContext *ctx, JSValueConst, int argc, JSValueConst *argv) { return write_int<uintptr_t>(ctx, argv, argc); }

JSValue js_read_f32(JSContext *ctx, JSValueConst, int argc, JSValueConst *argv) {
    uintptr_t ptr; if (!to_ptr(ctx, argv[0], &ptr)) return JS_EXCEPTION;
    int64_t offset = 0;
    if (argc > 1 && !JS_IsUndefined(argv[1])) { if (JS_ToInt64(ctx, &offset, argv[1])) return JS_EXCEPTION; }
    float v; memcpy(&v, (void *)(ptr + offset), 4);
    return JS_NewFloat64(ctx, (double)v);
}
JSValue js_write_f32(JSContext *ctx, JSValueConst, int argc, JSValueConst *argv) {
    uintptr_t ptr; if (!to_ptr(ctx, argv[0], &ptr)) return JS_EXCEPTION;
    int64_t offset = 0; int value_idx = 1;
    if (argc >= 3) { if (JS_ToInt64(ctx, &offset, argv[1])) return JS_EXCEPTION; value_idx = 2; }
    double d; if (JS_ToFloat64(ctx, &d, argv[value_idx])) return JS_EXCEPTION;
    float v = (float)d; memcpy((void *)(ptr + offset), &v, 4);
    return JS_UNDEFINED;
}
JSValue js_read_f64(JSContext *ctx, JSValueConst, int argc, JSValueConst *argv) {
    uintptr_t ptr; if (!to_ptr(ctx, argv[0], &ptr)) return JS_EXCEPTION;
    int64_t offset = 0;
    if (argc > 1 && !JS_IsUndefined(argv[1])) { if (JS_ToInt64(ctx, &offset, argv[1])) return JS_EXCEPTION; }
    double v; memcpy(&v, (void *)(ptr + offset), 8);
    return JS_NewFloat64(ctx, v);
}
JSValue js_write_f64(JSContext *ctx, JSValueConst, int argc, JSValueConst *argv) {
    uintptr_t ptr; if (!to_ptr(ctx, argv[0], &ptr)) return JS_EXCEPTION;
    int64_t offset = 0; int value_idx = 1;
    if (argc >= 3) { if (JS_ToInt64(ctx, &offset, argv[1])) return JS_EXCEPTION; value_idx = 2; }
    double v; if (JS_ToFloat64(ctx, &v, argv[value_idx])) return JS_EXCEPTION;
    memcpy((void *)(ptr + offset), &v, 8);
    return JS_UNDEFINED;
}

// ---- copy / fill / compare ---------------------------------------------------

JSValue js_copy(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    // copy(destPtr, srcPtr, length)
    uintptr_t dst, src;
    if (!to_ptr(ctx, argv[0], &dst)) return JS_EXCEPTION;
    if (!to_ptr(ctx, argv[1], &src)) return JS_EXCEPTION;
    int64_t len = 0;
    if (JS_ToInt64(ctx, &len, argv[2])) return JS_EXCEPTION;
    if (len < 0) return JS_ThrowRangeError(ctx, "Jaly.memory.copy: length must be >= 0");
    memmove((void *)dst, (void *)src, (size_t)len);
    return JS_UNDEFINED;
}

JSValue js_fill(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    // fill(ptr, value, length)
    uintptr_t ptr;
    if (!to_ptr(ctx, argv[0], &ptr)) return JS_EXCEPTION;
    int64_t value = 0, len = 0;
    if (JS_ToInt64(ctx, &value, argv[1])) return JS_EXCEPTION;
    if (JS_ToInt64(ctx, &len, argv[2])) return JS_EXCEPTION;
    if (len < 0) return JS_ThrowRangeError(ctx, "Jaly.memory.fill: length must be >= 0");
    memset((void *)ptr, (int)(value & 0xff), (size_t)len);
    return JS_UNDEFINED;
}

JSValue js_compare(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    // compare(ptrA, ptrB, length) -> -1 | 0 | 1
    uintptr_t a, b;
    if (!to_ptr(ctx, argv[0], &a)) return JS_EXCEPTION;
    if (!to_ptr(ctx, argv[1], &b)) return JS_EXCEPTION;
    int64_t len = 0;
    if (JS_ToInt64(ctx, &len, argv[2])) return JS_EXCEPTION;
    int r = memcmp((void *)a, (void *)b, (size_t)(len > 0 ? len : 0));
    return JS_NewInt32(ctx, r < 0 ? -1 : (r > 0 ? 1 : 0));
}

// ---- string helpers -----------------------------------------------------------

// writeString(ptr, str, offset?) -> bytes written (UTF-8, NUL-terminated)
JSValue js_write_string(JSContext *ctx, JSValueConst, int argc, JSValueConst *argv) {
    uintptr_t ptr;
    if (!to_ptr(ctx, argv[0], &ptr)) return JS_EXCEPTION;
    size_t slen = 0;
    const char *s = JS_ToCStringLen(ctx, &slen, argv[1]);
    if (!s) return JS_EXCEPTION;
    int64_t offset = 0;
    if (argc > 2 && !JS_IsUndefined(argv[2])) { if (JS_ToInt64(ctx, &offset, argv[2])) { JS_FreeCString(ctx, s); return JS_EXCEPTION; } }

    memcpy((void *)(ptr + offset), s, slen);
    ((uint8_t *)(ptr + offset))[slen] = 0;
    JS_FreeCString(ctx, s);
    return JS_NewInt64(ctx, (int64_t)slen + 1);
}

// readString(ptr, offset?, maxLen?) -> string, reads until NUL or maxLen
JSValue js_read_string(JSContext *ctx, JSValueConst, int argc, JSValueConst *argv) {
    uintptr_t ptr;
    if (!to_ptr(ctx, argv[0], &ptr)) return JS_EXCEPTION;
    int64_t offset = 0, max_len = 1 << 20; // 1MB safety cap on read length, not a permission
    if (argc > 1 && !JS_IsUndefined(argv[1])) { if (JS_ToInt64(ctx, &offset, argv[1])) return JS_EXCEPTION; }
    if (argc > 2 && !JS_IsUndefined(argv[2])) { if (JS_ToInt64(ctx, &max_len, argv[2])) return JS_EXCEPTION; }

    const char *base = (const char *)(ptr + offset);
    int64_t n = 0;
    while (n < max_len && base[n] != '\0') n++;
    return JS_NewStringLen(ctx, base, (size_t)n);
}

// ---- zero-copy native view ------------------------------------------------------

// view(ptr, length) -> ArrayBuffer that directly wraps the native memory
// (no copy). Mutating it mutates the real memory at `ptr`. QuickJS is told
// not to manage this memory (realloc_func = nullptr), so freeing it remains
// the caller's responsibility via Jaly.memory.free().
JSValue js_view(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    uintptr_t ptr;
    if (!to_ptr(ctx, argv[0], &ptr)) return JS_EXCEPTION;
    int64_t len = 0;
    if (JS_ToInt64(ctx, &len, argv[1])) return JS_EXCEPTION;
    if (len < 0) return JS_ThrowRangeError(ctx, "Jaly.memory.view: length must be >= 0");

    return JS_NewArrayBuffer(ctx, (uint8_t *)ptr, (size_t)len, 0, nullptr, nullptr, false);
}

// bufferAddress(arrayBuffer) -> raw pointer to a JS-owned ArrayBuffer's data.
// Lets a script hand JS-side buffers to native calls without copying.
JSValue js_buffer_address(JSContext *ctx, JSValueConst, int, JSValueConst *argv) {
    size_t size = 0;
    uint8_t *p = JS_GetArrayBuffer(ctx, &size, argv[0]);
    if (!p) return JS_ThrowTypeError(ctx, "Jaly.memory.bufferAddress: expected an ArrayBuffer");
    return from_ptr(ctx, (uintptr_t)p);
}

const JSCFunctionListEntry memory_funcs[] = {
    JS_CFUNC_DEF("alloc", 1, js_alloc),
    JS_CFUNC_DEF("calloc", 2, js_calloc),
    JS_CFUNC_DEF("realloc", 2, js_realloc),
    JS_CFUNC_DEF("free", 1, js_free),

    JS_CFUNC_DEF("add", 2, js_add),
    JS_CFUNC_DEF("isNull", 1, js_is_null),

    JS_CFUNC_DEF("read8", 1, js_read8),
    JS_CFUNC_DEF("read16", 1, js_read16),
    JS_CFUNC_DEF("read32", 1, js_read32),
    JS_CFUNC_DEF("read64", 1, js_read64),
    JS_CFUNC_DEF("readPtr", 1, js_readPtr),
    JS_CFUNC_DEF("readF32", 1, js_read_f32),
    JS_CFUNC_DEF("readF64", 1, js_read_f64),
    JS_CFUNC_DEF("readString", 1, js_read_string),

    JS_CFUNC_DEF("write8", 2, js_write8),
    JS_CFUNC_DEF("write16", 2, js_write16),
    JS_CFUNC_DEF("write32", 2, js_write32),
    JS_CFUNC_DEF("write64", 2, js_write64),
    JS_CFUNC_DEF("writePtr", 2, js_writePtr),
    JS_CFUNC_DEF("writeF32", 2, js_write_f32),
    JS_CFUNC_DEF("writeF64", 2, js_write_f64),
    JS_CFUNC_DEF("writeString", 2, js_write_string),

    JS_CFUNC_DEF("copy", 3, js_copy),
    JS_CFUNC_DEF("fill", 3, js_fill),
    JS_CFUNC_DEF("compare", 3, js_compare),

    JS_CFUNC_DEF("view", 2, js_view),
    JS_CFUNC_DEF("bufferAddress", 1, js_buffer_address),
};

} // namespace

JSValue jaly_memory_create(JSContext *ctx) {
    JSValue obj = JS_NewObject(ctx);
    JS_SetPropertyFunctionList(ctx, obj, memory_funcs,
        sizeof(memory_funcs) / sizeof(memory_funcs[0]));
    return obj;
}
